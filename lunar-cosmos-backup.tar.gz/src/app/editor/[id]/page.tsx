"use client";

import WorkflowEditor from "@/components/workflow/WorkflowEditor";
import { useRef, useState, useEffect, use } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

import { Terminal, Moon, Sun } from "lucide-react";
import { ExecutionLogPanel } from "@/components/workflow/ExecutionLogPanel";
import { useTheme } from "@/components/ThemeProvider";

export default function EditorPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = use(params);
    const { theme, toggleTheme } = useTheme();
    const router = useRouter();
    const { status } = useSession();
    const saveRef = useRef<any>(null);
    const [saving, setSaving] = useState(false);
    const [running, setRunning] = useState(false);
    const [initialData, setInitialData] = useState<any>(null);
    const [loading, setLoading] = useState(id !== 'new');

    const [executionLogs, setExecutionLogs] = useState<any[]>([]);
    const [showLogs, setShowLogs] = useState(false);

    useEffect(() => {
        if (status === 'unauthenticated') {
            router.push('/');
        }
    }, [status, router]);

    useEffect(() => {
        if (id !== 'new' && status === 'authenticated') {
            fetch(`/api/workflows/${id}`)
                .then(res => res.json())
                .then(data => {
                    setInitialData({ nodes: data.nodes, edges: data.edges });
                    setLoading(false);
                })
                .catch(err => {
                    console.error(err);
                    setLoading(false);
                });
        } else if (id === 'new') {
            setLoading(false);
        }
    }, [id, status]);

    const handleSave = async () => {
        if (!saveRef.current) return;
        setSaving(true);
        const flowData = saveRef.current();

        const isNew = id === 'new';
        const method = isNew ? 'POST' : 'PUT';
        const url = isNew ? '/api/workflows' : `/api/workflows/${id}`;

        try {
            const body = {
                name: isNew ? `Workflow ${new Date().toLocaleTimeString()}` : undefined,
                nodes: flowData.nodes,
                edges: flowData.edges
            };

            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });

            const result = await res.json();

            if (isNew && result.id) {
                router.push(`/editor/${result.id}`);
            } else {
                // alert("Saved successfully!"); // Optional: suppress if auto-saving before run
            }
            return result.id || id; // Return ID for run
        } catch (e) {
            alert("Failed to save");
            console.error(e);
            return null;
        } finally {
            setSaving(false);
        }
    };

    const handleRun = async () => {
        setRunning(true);

        // Auto-save first
        const currentId = await handleSave();
        if (!currentId || currentId === 'new') {
            alert("Please save the workflow first.");
            setRunning(false);
            return;
        }

        try {
            const res = await fetch('/api/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    workflowId: currentId,
                    input: "Start the review process for Chapter 1." // Default input for now
                })
            });
            const data = await res.json();
            console.log("Execution Result:", data);

            if (data.logs) {
                setExecutionLogs(data.logs);
                setShowLogs(true);
            }

            // alert("Workflow Finished! Check console for logs (UI coming soon). \n\nOutput: " + JSON.stringify(data.finalOutputs));
        } catch (e) {
            console.error(e);
            alert("Execution failed.");
        }
        setRunning(false);
    };

    if (status === 'loading' || loading) return <div className="p-8 dark:text-gray-100">Loading workflow...</div>;
    if (status === 'unauthenticated') return null; // Redirecting...

    return (
        <div className="h-screen flex flex-col dark:bg-gray-900 dark:text-gray-100">
            <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between z-10 dark:bg-gray-800 dark:border-gray-700">
                <div>
                    <div className="text-xs text-gray-500 uppercase font-bold tracking-wider dark:text-gray-400">Workflow Editor</div>
                    <h1 className="text-lg font-bold">
                        {id === 'new' ? 'New Pipeline' : 'Editing Pipeline'}
                    </h1>
                </div>
                <div className="flex gap-2 items-center">
                    <button
                        onClick={toggleTheme}
                        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors mr-2 text-gray-500 dark:text-gray-400"
                        title="Toggle Theme"
                    >
                        {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                    </button>
                    <button
                        onClick={handleRun}
                        disabled={saving || running}
                        className="bg-green-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-green-700 disabled:opacity-50 flex items-center gap-2"
                    >
                        {running ? 'Running...' : 'Run Workflow'}
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={saving || running}
                        className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
                    >
                        {saving ? 'Saving...' : 'Save Workflow'}
                    </button>
                    <button
                        onClick={() => setShowLogs(!showLogs)}
                        className={`p-2 rounded-md border text-sm font-medium ${showLogs ? 'bg-blue-50 border-blue-200 text-blue-600' : 'bg-white border-gray-300 text-gray-600 hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300'}`}
                        title="Toggle Execution Logs"
                    >
                        <Terminal className="w-5 h-5" />
                    </button>
                </div>
            </header>
            <div className="flex-1 relative">
                <WorkflowEditor initialData={initialData} onSaveRef={saveRef} />
                <ExecutionLogPanel
                    logs={executionLogs}
                    isOpen={showLogs}
                    onClose={() => setShowLogs(false)}
                />
            </div>
        </div >
    );
}
