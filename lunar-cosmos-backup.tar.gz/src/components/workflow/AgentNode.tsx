import { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { MoreHorizontal, PlayCircle, StopCircle, X } from 'lucide-react';

const AgentNode = ({ data, id }: NodeProps) => {
    const isStart = data.role === 'trigger';
    const isEnd = data.isEnd;

    const toggleStart = () => {
        data.onUpdate?.(id, { role: isStart ? 'agent' : 'trigger' });
    };

    const toggleEnd = () => {
        data.onUpdate?.(id, { isEnd: !isEnd });
    };

    return (
        <div className={`shadow-md rounded-lg bg-white border-2 min-w-[200px] ${data.color || 'border-gray-200'} ${isStart ? 'ring-4 ring-green-400' : ''} ${isEnd ? 'ring-4 ring-red-400' : ''}`}>

            {/* Context Actions (Always visible now) */}
            <div className="absolute -top-8 left-0 flex gap-1 bg-white p-1 rounded border shadow-sm z-50">
                <button
                    onClick={toggleStart}
                    className={`p-1 rounded hover:bg-gray-100 ${isStart ? 'text-green-600' : 'text-gray-400'}`}
                    title="Set as Trigger Node"
                >
                    <PlayCircle className="w-4 h-4" />
                </button>
                <button
                    onClick={toggleEnd}
                    className={`p-1 rounded hover:bg-gray-100 ${isEnd ? 'text-red-600' : 'text-gray-400'}`}
                    title="Set as Termination Node"
                >
                    <StopCircle className="w-4 h-4" />
                </button>
            </div>

            <div className="flex items-center justify-between p-3 border-b border-gray-100 bg-gray-50/50 rounded-t-lg group">
                <div className="font-bold text-gray-700 flex items-center gap-2">
                    {data.label}
                    {isStart && <span className="text-[10px] bg-green-100 text-green-700 px-1 rounded">START</span>}
                    {isEnd && <span className="text-[10px] bg-red-100 text-red-700 px-1 rounded">END</span>}
                </div>
                <button
                    onClick={() => data.onDelete?.(id)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                >
                    <X className="w-4 h-4" />
                </button>
            </div>
            <div className="p-3 text-sm text-gray-500 bg-white rounded-b-lg">
                <div className="uppercase text-[10px] font-bold tracking-wider mb-1 text-gray-300">{data.role}</div>
                {/* Visual Handles */}
                <Handle type="target" position={Position.Top} className="w-3 h-3 bg-gray-400" />
                <Handle type="source" position={Position.Bottom} className="w-3 h-3 bg-gray-400" />
            </div>
        </div>
    );
};

export default memo(AgentNode);
