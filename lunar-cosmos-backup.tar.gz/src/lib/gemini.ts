import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export class GeminiClient {
    private model: any;

    constructor() {
        this.model = genAI.getGenerativeModel({ model: "gemini-3-pro-preview" });
    }

    async chat(message: string, systemInstruction: string, history: any[] = []) {
        // Gemini 3 Pro (Preview) supports system instructions via model config

        const chatModel = genAI.getGenerativeModel({
            model: "gemini-3-pro-preview",
            systemInstruction: {
                parts: [{ text: systemInstruction }],
                role: "system"
            }
        });

        const chat = chatModel.startChat({
            history: history.map(h => ({
                role: h.role === 'user' ? 'user' : 'model',
                parts: [{ text: h.content }]
            })),
            generationConfig: {
                maxOutputTokens: 2000,
            },
        });

        const result = await chat.sendMessage(message);
        const response = await result.response;
        return response.text();
    }
}

export const geminiClient = new GeminiClient();
